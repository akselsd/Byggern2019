#ifndef SPEAKER_DRIVER_H_INCLUDED
#define SPEAKER_DRIVER_H_INCLUDED

void speaker_init(void);
void speaker_play_shoot(void);
void speaker_life_lost(void);

#endif
