#ifndef PWM_DRIVER_H_INCLUDED
#define PWM_DRIVER_H_INCLUDED

void pwm_init(void);
void pwm_set_duty_cycle(float percentage);

#endif