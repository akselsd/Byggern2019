#ifndef SRAM_TEST_H
#define SRAM_TEST_H

void SRAM_test(void);

#endif
