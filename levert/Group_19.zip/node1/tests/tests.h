#ifndef INCLUDE_TESTS_H
#define INCLUDE_TESTS_H

// Always flush stderr?

int test_uart_output_streams(void);
void test_usb_multifunction_board(void);
#endif
