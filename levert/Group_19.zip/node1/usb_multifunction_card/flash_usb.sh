sudo avrdude -p usb1287 -c atmelice -U flash:w:TouchToPWM.hex:i
